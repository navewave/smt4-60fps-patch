SMT IV 60 FPS patch - build 8 (stable) - USA 1.0
Game: Shin Megami Tensei IV, USA 1.0 (title 00040000000E5C00)
Game logic still runs at 30 Hz (original speed); the in-between frames are interpolated.

Pick ONE of the two patch folders:

1) Azahar_full  (recommended for Azahar: 60 fps + all smoothing fixes + right-stick camera)
   Copy the folder "00040000000E5C00" into:  Azahar/load/mods/
   Result:
     Azahar/load/mods/00040000000E5C00/exheader.bin
     Azahar/load/mods/00040000000E5C00/exefs/code.ips
   exheader.bin is REQUIRED. Without it the game will not start
   (log shows "Failed to load ROM (Error 12)"). Always replace both files together.

2) Real_3DS  (Luma3DS)
   Copy to SD:  /luma/titles/00040000000E5C00/code.ips
   Enable "Enable game patching" in the Luma config (hold SELECT at boot).
   Basic 60 fps (logic gate, camera/model/sprite interpolation) only. The other
   fixes need memory that a real 3DS does not allow code to run from, so they
   are emulator-only.

Optional cheats (Cheats folder): ghosting fix and bloom removal by the GBAtemp
thread "Shin Megami Tensei IV and IV:A Ghosting Fix":
  https://gbatemp.net/threads/shin-megami-tensei-iv-and-iv-a-ghosting-fix.684175/
  Azahar:    copy Cheats/Azahar/00040000000E5C00.txt into Azahar's user folder: Azahar/cheats/
             (Windows: %APPDATA%\Azahar\cheats), then tick the codes in Azahar's cheat
             window while the game is running
  Luma3DS:   copy Cheats/Luma3DS/cheats/00040000000E5C00.txt to SD:/cheats/
             (open the Rosalina menu with L+Down+Select > Cheats in game)
  "Ghosting Fix + Bloom Removal" holds only the bloom lines: enable it together with "Ghosting Fix".

Smoothed at 60 fps: 3D characters and camera, menus and slides, maps, battle
effects, area select / event backdrop pans, event portraits (slides, fades,
zooms, Burroughs), compendium / status / talk panel / battle HP bars, right-stick camera.

Known remaining: pre-rendered video cutscenes stay at their encoded frame rate;
outside battle, flame / glow / scrolling-texture effects stay on the game's
original 30 Hz frames (keeps fire billboards correct); bottom-screen map markers
move in whole pixels; a one-frame camera jump at the start of the terminal
teleport scene. Save states made with an older build keep running the older patch.
