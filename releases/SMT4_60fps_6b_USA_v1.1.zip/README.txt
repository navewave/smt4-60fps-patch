SMT IV 60 FPS patch - build 6b (stable) - USA, game VERSION 1.1
Game: Shin Megami Tensei IV, USA (title 00040000000E5C00) WITH the 1.1 update installed.
!! Use this package only if the game actually runs 1.1 code. For an un-updated game use
   the 1.0 package. The wrong version will not boot or will crash. !!
Game logic still runs at 30 Hz (original speed); the in-between frames are interpolated.

Pick ONE of the three folders:

1) Azahar_full  (recommended for Azahar: 60 fps + all smoothing fixes + right-stick camera)
   The 1.1 update must be installed in Azahar.
   Copy the folder "00040000000E5C00" into:  Azahar/load/mods/
   Result:
     Azahar/load/mods/00040000000E5C00/exheader.bin
     Azahar/load/mods/00040000000E5C00/exefs/code.ips
   (Azahar applies mods for the update under the base title id.)
   exheader.bin is REQUIRED and is the 1.1 one - do not mix with the 1.0 package.
   Without it the game will not start (log: "Failed to load ROM (Error 12)").

2) Azahar_60fps_only  (Azahar, no exheader needed)
   Same location, only exefs/code.ips. 60 fps and basic smoothing; no right-stick
   camera and none of the extended fixes.

3) Real_3DS  (Luma3DS)
   Copy to SD:  /luma/titles/00040000000E5C00/code.ips
   Enable "Enable game patching" in the Luma config (hold SELECT at boot).
   Basic 60 fps only. If the game crashes at boot, your console is running 1.0
   code: use the 1.0 package instead.

Status: built from the same source as the tested 1.0 build 6b, with every game
address re-mapped to 1.1 and checked against the 1.1 code. Not yet play-tested on 1.1.

Known remaining (same as 1.0): Burroughs' hologram scale-in and diorama backdrop
pans are 30 Hz; outside battle, flame / glow / scrolling-texture effects keep the
original 30 Hz frames; occasional slowdowns.
