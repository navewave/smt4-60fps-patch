SMT IV 60 FPS patch - build 6b (stable)
Game: Shin Megami Tensei IV, USA, version 1.0 (title 00040000000E5C00)
Game logic still runs at 30 Hz (original speed); the in-between frames are interpolated.

Pick ONE of the three folders:

1) Azahar_full  (recommended for Azahar: 60 fps + all smoothing fixes + right-stick camera)
   Copy the folder "00040000000E5C00" into:  Azahar/load/mods/
   Result:
     Azahar/load/mods/00040000000E5C00/exheader.bin
     Azahar/load/mods/00040000000E5C00/exefs/code.ips
   exheader.bin is REQUIRED. Without it the game will not start
   (log shows "Failed to load ROM (Error 12)").

2) Azahar_60fps_only  (Azahar, no exheader needed)
   Same location, only exefs/code.ips. 60 fps and most smoothing, but no
   right-stick camera and none of the fixes that need the extra memory
   (torch fix, stats zoom fix, generic menu slide smoothing, field tiles).

3) Real_3DS  (Luma3DS)
   Copy to SD:  /luma/titles/00040000000E5C00/code.ips
   Enable "Enable game patching" in the Luma config (hold SELECT at boot).
   Basic 60 fps (logic gate, camera/model/sprite interpolation) only.
   Torch fix and other extended fixes are emulator-only for now.

Known remaining: Burroughs' hologram scale-in and the diorama backdrop pans
(area select, some event backdrops) are 30 Hz; outside battle, flame / glow /
scrolling-texture effects stay on the game's original 30 Hz frames (keeps fire
billboards correct; battle effects are smoothed); occasional slowdowns (raise
Azahar's CPU clock or lower the resolution scale if needed).
